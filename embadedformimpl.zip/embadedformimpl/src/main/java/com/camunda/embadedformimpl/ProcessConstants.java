package com.camunda.embadedformimpl;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "embadedformimpl"; // BPMN Process ID

}
